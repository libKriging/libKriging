import csv, sys
A={(r['model'],r['kernel'],r['function'],r['n'],r['set']):r for r in csv.DictReader(open(sys.argv[1]))}
for r in csv.DictReader(open(sys.argv[2])):
    k=(r['model'],r['kernel'],r['function'],r['n'],r['set'])
    if k not in A: continue
    o=A[k]
    dn=float(r['nlpd'])-float(o['nlpd']); rr=float(r['rmse'])/float(o['rmse'])
    if abs(dn)>0.1 or abs(rr-1)>0.1 or abs(float(r['cov95'])-float(o['cov95']))>0.03:
        print(' '.join(k), 'rmse x%.3f nlpd %.2f -> %.2f cov %s -> %s res %s fb %s/%s ll %.2f -> %.2f'%(rr,float(o['nlpd']),float(r['nlpd']),o['cov95'],r['cov95'],r.get('res_last',r.get('res_max')),r['res_fb'],r['res_chk'],float(o['ll']),float(r['ll'])))
