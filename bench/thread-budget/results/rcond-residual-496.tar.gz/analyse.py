# analyse.py <on.csv> <inf.csv> [tol...]: residual of the exact committed model vs outcome
import sys, csv, math
def load(p):
    d = {}
    for r in csv.DictReader(open(p)):
        d[(r['model'], r['kernel'], r['function'], r['n'], r['set'])] = r
    return d
on, ex = load(sys.argv[1]), load(sys.argv[2])
tols = [float(t) for t in sys.argv[3:]] or [1e-7, 1e-6, 1e-5, 1e-4, 1e-3]
keys = sorted(set(on) & set(ex))
rows = []
for k in keys:
    a, b = on[k], ex[k]
    f = lambda r, c: float(r[c]) if r[c] not in ('', 'nan') else math.nan
    rows.append(dict(k=k, res=f(b, 'res_last' if 'res_last' in b else 'res_max'), rr_on=int(a['rr_fit']), same_theta=a['theta'] == b['theta'],
                     rmse_on=f(a, 'rmse'), rmse_ex=f(b, 'rmse'), interp_on=f(a, 'interp'), interp_ex=f(b, 'interp'),
                     nlpd_on=f(a, 'nlpd'), nlpd_ex=f(b, 'nlpd')))
print(f"{len(rows)} fits; theta differs on {sum(not r['same_theta'] for r in rows)}")
diff = [r for r in rows if abs(r['rmse_ex'] / r['rmse_on'] - 1) > 1e-6]
print(f"rmse differs (exact vs on) on {len(diff)} fits")
print("model kernel function n set | res(exact) | rmse exact/on | interp on / exact | nlpd on / exact | theta=")
for r in sorted(diff, key=lambda r: r['res']):
    print(" ".join(r['k']), f"| {r['res']:.2e} | {r['rmse_ex']/r['rmse_on']:.3f} | {r['interp_on']:.2e} / {r['interp_ex']:.2e} | {r['nlpd_on']:.2f} / {r['nlpd_ex']:.2f} | {r['same_theta']}")
import collections
print("\nresidual distribution, fits with identical outcome (exact = on):")
same = [r['res'] for r in rows if r not in diff and not math.isnan(r['res'])]
for t in tols:
    print(f"  > {t:g}: {sum(x > t for x in same)} of {len(same)}")
print("\nsimulated tolerance (fallback = outcome of on), on fits where exact != on:")
for t in tols:
    win = sum(1 for r in diff if r['res'] <= t and r['rmse_ex'] < 0.9 * r['rmse_on']) + sum(1 for r in diff if r['res'] > t and r['rmse_on'] < 0.9 * r['rmse_ex'])
    lose = sum(1 for r in diff if r['res'] <= t and r['rmse_ex'] > 1.1 * r['rmse_on']) + sum(1 for r in diff if r['res'] > t and r['rmse_on'] > 1.1 * r['rmse_ex'])
    kept = sum(1 for r in diff if r['res'] <= t)
    print(f"  tol {t:g}: exact kept {kept}/{len(diff)}; best-of-two by RMSE ±10 %: right {win}, wrong {lose}")
