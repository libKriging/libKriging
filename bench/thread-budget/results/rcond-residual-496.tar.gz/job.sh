#!/bin/bash
# job.sh <name> <variant> <tol> <models> <kernels> <functions> <ns> <sets> [first]
cd /tmp/claude-0/runs
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 LK_RCOND=$2 LK_RES_TOL=$3
/tmp/claude-0/build/rcond_study $4 $5 none $6 $7 $8 BFGS4 ${9:-0} > $1.csv 2> $1.err
